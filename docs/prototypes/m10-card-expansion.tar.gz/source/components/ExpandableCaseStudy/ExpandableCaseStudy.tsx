"use client";

import Image from "next/image";
import { useEffect, useId, useRef, useState, type ReactNode } from "react";

import styles from "./ExpandableCaseStudy.module.css";

type ExpandableCaseStudyProps = {
  children: ReactNode;
  className?: string;
  title: string;
  image: string;
  alt: string;
};

export function ExpandableCaseStudy({ children, className, title, image, alt }: ExpandableCaseStudyProps) {
  const titleId = useId();
  const dialogId = useId();
  const sourceRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const animationRef = useRef<Animation | null>(null);
  const unlockRef = useRef<(() => void) | null>(null);
  const closingRef = useRef(false);
  const [open, setOpen] = useState(false);

  useEffect(() => () => {
    animationRef.current?.cancel();
    unlockRef.current?.();
  }, []);

  function sourceTransform() {
    const source = sourceRef.current!;
    const panel = panelRef.current!;
    const from = source.getBoundingClientRect();
    const to = panel.getBoundingClientRect();
    const matrix = new DOMMatrix(getComputedStyle(source).transform);
    const angle = Math.atan2(matrix.b, matrix.a);
    // Use the unrotated dimensions so the panel starts at the actual card size.
    const width = source.offsetWidth;
    const height = source.offsetHeight;
    const x = from.left + from.width / 2 - Math.cos(angle) * width / 2 + Math.sin(angle) * height / 2;
    const y = from.top + from.height / 2 - Math.sin(angle) * width / 2 - Math.cos(angle) * height / 2;
    return `translate(${x - to.left}px, ${y - to.top}px) rotate(${angle}rad) scale(${width / to.width}, ${height / to.height})`;
  }

  function openCase() {
    const dialog = dialogRef.current;
    const panel = panelRef.current;
    if (!dialog || !panel || dialog.open) return;

    const scrollY = window.scrollY;
    const body = document.body;
    const previous = { position: body.style.position, top: body.style.top, width: body.style.width, paddingRight: body.style.paddingRight };
    const scrollbar = window.innerWidth - document.documentElement.clientWidth;
    const padding = parseFloat(getComputedStyle(body).paddingRight);
    Object.assign(body.style, { position: "fixed", top: `${-scrollY}px`, width: "100%", paddingRight: `${padding + scrollbar}px` });
    unlockRef.current = () => {
      Object.assign(body.style, previous);
      window.scrollTo({ top: scrollY, behavior: "instant" });
      unlockRef.current = null;
    };

    closingRef.current = false;
    dialog.dataset.closing = "false";
    panel.scrollTop = 0;
    dialog.showModal();
    closeRef.current?.focus({ preventScroll: true });
    setOpen(true);

    if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      animationRef.current = panel.animate(
        [{ transform: sourceTransform(), borderRadius: "24px" }, { transform: "none", borderRadius: getComputedStyle(panel).borderRadius }],
        { duration: 300, easing: "cubic-bezier(0.22, 1, 0.36, 1)" },
      );
    }
  }

  async function closeCase() {
    const dialog = dialogRef.current;
    const panel = panelRef.current;
    if (!dialog?.open || !panel || closingRef.current) return;
    closingRef.current = true;
    dialog.dataset.closing = "true";

    const currentTransform = getComputedStyle(panel).transform;
    animationRef.current?.cancel();
    if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      animationRef.current = panel.animate(
        [{ transform: currentTransform, opacity: 1 }, { transform: sourceTransform(), borderRadius: "24px", opacity: 0 }],
        { duration: 190, easing: "cubic-bezier(0.4, 0, 0.2, 1)", fill: "forwards" },
      );
      await animationRef.current.finished.catch(() => {});
    }
    dialog.close();
    animationRef.current?.cancel();
  }

  function finishClose() {
    unlockRef.current?.();
    setOpen(false);
    closingRef.current = false;
    triggerRef.current?.focus({ preventScroll: true });
  }

  return (
    <div className={[styles.source, className].filter(Boolean).join(" ")} ref={sourceRef}>
      {children}
      <button
        aria-label={`Open case study: ${title}`}
        aria-haspopup="dialog"
        aria-controls={dialogId}
        aria-expanded={open}
        className={styles.trigger}
        onClick={openCase}
        ref={triggerRef}
        type="button"
      />
      <dialog
        aria-labelledby={titleId}
        className={styles.dialog}
        id={dialogId}
        onCancel={(event) => { event.preventDefault(); void closeCase(); }}
        onClose={finishClose}
        ref={dialogRef}
      >
        <div className={styles.panel} ref={panelRef}>
          <button aria-label="Close case study" className={styles.close} onClick={() => void closeCase()} ref={closeRef} type="button">
            <Image alt="" src="/projects/shared/close.svg" width={40} height={40} />
          </button>
          <article className={styles.hero}>
            <h2 className={styles.title} id={titleId}>{title}</h2>
            <Image alt={alt} className={styles.heroImage} src={image} width={960} height={540} sizes="(max-width: 760px) calc(100vw - 64px), 46vw" />
          </article>
        </div>
      </dialog>
    </div>
  );
}
