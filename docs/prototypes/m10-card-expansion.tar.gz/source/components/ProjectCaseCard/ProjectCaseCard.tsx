import Image from "next/image";
import { ExpandableCaseStudy } from "../ExpandableCaseStudy/ExpandableCaseStudy";

import styles from "./ProjectCaseCard.module.css";

type ProjectCaseCardProps = {
  alt: string;
  category: string;
  className?: string;
  detail?: { image: string; alt: string };
  height: number;
  image: string;
  size: "large" | "small";
  title: string;
  width: number;
};

export function ProjectCaseCard({
  alt,
  category,
  className,
  detail,
  height,
  image,
  size,
  title,
  width,
}: ProjectCaseCardProps) {
  const card = (
    <figure className={[styles.card, !detail && className].filter(Boolean).join(" ")} data-project-case-card data-size={size}>
      <Image
        alt={alt}
        className={styles.image}
        draggable={false}
        height={height}
        sizes={size === "small" ? "(max-width: 600px) 50vw, 265px" : "(max-width: 760px) calc(100vw - 32px), 550px"}
        src={image}
        width={width}
      />
      <figcaption className={styles.caption}>
        <span className={styles.info}>
          <strong className={styles.title}>{title}</strong>
          <small className={styles.category}>{category}</small>
        </span>
        {detail ? <span className={styles.lock} aria-hidden="true">↗</span> : <Image alt="" className={styles.lock} src="/projects/shared/lock.svg" width={24} height={24} />}
      </figcaption>
    </figure>
  );

  return detail ? (
    <ExpandableCaseStudy className={className} title={title} image={detail.image} alt={detail.alt}>
      {card}
    </ExpandableCaseStudy>
  ) : card;
}
